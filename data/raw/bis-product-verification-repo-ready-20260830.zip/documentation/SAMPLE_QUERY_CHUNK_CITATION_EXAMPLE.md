# Sample Query -> Chunk -> Citation

## Query

Which BIS standard is mapped to mobile phones?

## Matching logic

Search terms: mobile phone, handset, BIS CRS, Scheme II.

## Expected chunk

Use the chunk whose `document_id` is `DOC-STD-002`, and optionally combine with `DOC-STD-003` for Indian language support.

## Citation

Return the BIS Scheme II source URL from the chunk. Do not claim that a user's physical phone is certified unless licence/registration verification is also performed.
