# What to Explain to the System Architect

The knowledge base has three layers:

1. Seed structured data: verified BIS product/service mappings.
2. Official source captures: raw and cleaned BIS pages plus linked official PDFs where available.
3. RAG chunks: citation-ready JSONL with source traceability.

Architectural point: the LLM should retrieve evidence first, then answer. It should not invent certification status or full standard clauses. Product detection can identify a likely standard mapping, but verification must use BIS licence/registration/HUID workflows.
