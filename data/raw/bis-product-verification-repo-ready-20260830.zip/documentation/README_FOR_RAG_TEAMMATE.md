# ManakAI BIS RAG Handoff

This folder is the Data/Knowledge Engineer handoff for the SIH 2026 ManakAI MVP.

## What to index first

1. `chunks/bis_rag_chunks.jsonl`
2. `metadata/chunk_metadata_schema.json`
3. `metadata/source_traceability_map.json`
4. `document_inventory/bis_document_inventory.csv`

## Retrieval rule

Always return `source_url` with the answer. If the user asks for certification status of a real product, do not say it is certified only because an IS number was detected. Tell the user to verify the licence/registration/HUID using the official BIS source or BIS Care App.

## Best MVP queries

- Which BIS standard is mapped to mobile phones?
- Does a helmet for two-wheeler riders come under BIS?
- What is Scheme II/CRS?
- How can a consumer verify an ISI mark or HUID?
- Which standard is mapped to microwave ovens?

## Known limitation

The package preserves official BIS list/service-page evidence. Full Indian Standard clause documents were not publicly obtained from the official pages, so clause-level answers should be disabled unless your team later adds licensed official standard text.
