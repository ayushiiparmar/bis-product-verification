# Repository File Mapping

This mapping reorganizes `BIS_DATA_KNOWLEDGE_ENGINEER_FINAL` into the existing `bis-product-verification` repository folders without rebuilding or fabricating data.

## raw/

From `BIS_DATA_KNOWLEDGE_ENGINEER_FINAL/raw_documents/`.

Purpose: original BIS source material exactly as collected.

Contains:
- 8 official BIS HTML pages
- 20 official linked BIS PDFs

## processed/

From `BIS_DATA_KNOWLEDGE_ENGINEER_FINAL/cleaned_documents/`.

Purpose: cleaned/extracted/normalized material created from raw source material.

Also contains:
- `processed/ocr_output/`, copied from `BIS_DATA_KNOWLEDGE_ENGINEER_FINAL/ocr_output/`

OCR note:
- OCR was not completed.
- One scanned PDF is flagged as OCR-required.
- The OCR manifest preserves that limitation honestly.

## documents/

From `BIS_DATA_KNOWLEDGE_ENGINEER_FINAL/document_inventory/`.

Purpose: organized document-level inventory and source tracking.

Contains:
- `bis_document_inventory.csv`
- `bis_document_inventory.json`
- `fetch_log.json`
- `official_source_links_extracted.json`

No duplicate raw PDFs or duplicate cleaned text were placed here.

## chunks/

From `BIS_DATA_KNOWLEDGE_ENGINEER_FINAL/chunks/`.

Purpose: final RAG data only.

Contains:
- `bis_rag_chunks.jsonl`
- `bis_rag_chunks.json`

## metadata/

From `BIS_DATA_KNOWLEDGE_ENGINEER_FINAL/metadata/`.

Purpose: schemas, configuration, data dictionary, and traceability map.

Contains:
- `chunk_metadata_schema.json`
- `chunking_config.json`
- `data_dictionary.json`
- `source_traceability_map.json`

## Other Preserved Work

Additional useful work is preserved outside the five core repository folders:

- `structured_data/`: original seed dataset JSON and Excel workbook
- `qa/`: QA, citation QA, validation summary
- `documentation/`: teammate handoff and pipeline docs
- `processing/`: pipeline script for reproducibility

## What Was Not Added

- No invented BIS PDFs
- No fabricated clauses
- No fake OCR output
- No credentials, `.env`, API keys, or secrets

