# BIS Data Pipeline Documentation

Created: 2026-08-28

## Day 1 - Collection

The seed structured dataset was inspected first. Official BIS source URLs were collected from the seed and fetched into `raw_documents/`.

## Day 2 - Cleaning and OCR classification

HTML pages were cleaned into readable text. Linked official PDFs were downloaded where available and checked for extractable text. Scanned/mixed PDFs were flagged in `ocr_output/`.

## Day 3 - Section-aware chunking

Chunking uses the hierarchy: Document -> Section -> Subsection -> Clause -> Content. Seed mappings are kept as one chunk per row to preserve product-standard-source integrity.

## Day 4 - Chunk QA

Empty chunks, duplicate IDs, missing URLs, and broken inventory links were checked. Very short PDF chunks were removed.

## Day 5 - Citation QA

Every chunk includes source name and URL. PDF chunks include page numbers only when available from real PDF extraction.

## Day 6 - Final validation

JSON, JSONL, IDs, metadata, URL presence, OCR flags, and source traceability were validated.

## Day 7 - Handoff

Use `README_FOR_RAG_TEAMMATE.md`, `sample_query_chunk_citation_example.json`, and `qa/qa_report.json` for teammate explanation and demo.
