# ManakAI - BIS Product Verification Knowledge Base

ManakAI is an SIH 2026 MVP for an AI-powered assistant that helps users understand Indian Standards and BIS services using source-backed retrieval.

This repository contains the Data/Knowledge Engineer handoff: structured BIS seed data, official BIS source captures, cleaned/extracted text, RAG-ready chunks, metadata, QA reports, and documentation.

## Repository Folders

### raw/

Original BIS source material exactly as collected, before cleaning or processing.

Includes:
- Official BIS HTML source pages
- Official linked BIS PDFs

Do not edit these files. They are kept for traceability.

### processed/

Cleaned, extracted, and normalized material produced from `raw/`.

Includes:
- Cleaned text extracted from BIS HTML pages
- Cleaned text extracted from PDFs
- Cleaned seed standard/service records
- `processed/ocr_output/` with OCR status files and OCR manifest

Important: OCR was not completed. One scanned PDF was flagged as OCR-required, but no OCR engine was available locally.

### documents/

Document-level organization and inventory.

Includes:
- `bis_document_inventory.csv`
- `bis_document_inventory.json`
- `fetch_log.json`
- `official_source_links_extracted.json`

This folder is for tracking what source documents exist, where they came from, whether they were processed, and what limitations remain. It should not duplicate raw PDFs or cleaned text.

### chunks/

Final RAG-ready data.

Includes:
- `bis_rag_chunks.jsonl`
- `bis_rag_chunks.json`

Each chunk includes source traceability fields such as `source_name`, `source_url`, `document_id`, and extraction metadata.

### metadata/

Schema and traceability support for the RAG/backend team.

Includes:
- `chunk_metadata_schema.json`
- `chunking_config.json`
- `data_dictionary.json`
- `source_traceability_map.json`

### structured_data/

Original structured seed dataset preserved from the completed BIS MVP dataset.

Includes:
- 33 standards/product mappings
- 10 BIS service entries

### qa/

Validation and quality reports.

Includes:
- chunk integrity checks
- citation coverage report
- final validation summary

### documentation/

Human-readable handoff docs for the AI/RAG engineer, backend developer, and system architect.

### processing/

Pipeline script used to create the final package from the completed local data.

This is included for transparency and reproducibility. Do not run it unless you intentionally want to regenerate the package.

## RAG And Citation Approach

ManakAI should answer using retrieval-first logic:

1. Retrieve relevant chunks from `chunks/bis_rag_chunks.jsonl`.
2. Use metadata to identify the source document and source URL.
3. Answer only from retrieved evidence.
4. Always show the citation/source URL.
5. If the question asks for real product certification status, direct the user to BIS licence/registration/HUID verification rather than assuming certification.

## Dataset Scope

The current dataset contains:
- 33 standards/product mappings
- 10 BIS service entries
- 72 document inventory records
- 656 RAG chunks
- 100% chunk-level citation URL coverage
- 1 OCR-pending document

## Important Limitations

- Full Indian Standard PDFs for the 33 standards were not publicly obtainable from the official BIS pages used here.
- Clause-level answers should be disabled unless licensed/official full standard text is later added.
- Detecting an IS number or standard mapping does not prove a product is BIS certified.
- OCR was not completed; OCR-required files are only flagged.
- This dataset is for an SIH MVP prototype and should not be treated as legal/compliance advice.

## Recommended Files For Teammates

AI/LLM + RAG Engineer:
- `chunks/bis_rag_chunks.jsonl`
- `chunks/bis_rag_chunks.json`
- `metadata/chunk_metadata_schema.json`
- `metadata/chunking_config.json`
- `metadata/source_traceability_map.json`
- `documentation/README_FOR_RAG_TEAMMATE.md`

Backend Developer:
- `structured_data/bis_mvp_structured_dataset.original.json`
- `documents/bis_document_inventory.json`
- `documents/bis_document_inventory.csv`
- `metadata/data_dictionary.json`
- `qa/validation_summary.json`

System Architect:
- `documentation/DATA_PIPELINE_DOCUMENTATION.md`
- `documentation/SYSTEM_ARCHITECT_EXPLANATION.md`
- `qa/qa_report.json`
- `qa/citation_qa_report.json`

